@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "UNITY_EXE="
for /d %%D in ("C:\Program Files\Unity\Hub\Editor\*") do if exist "%%~fD\Editor\Unity.exe" set "UNITY_EXE=%%~fD\Editor\Unity.exe"
if not defined UNITY_EXE (
 echo Unity Editor not found. Install Unity 6 and Windows Build Support first.
 pause
 exit /b 2
)
"%UNITY_EXE%" -batchmode -quit -projectPath "%~dp0" -executeMethod LEFTBuild.BuildWindows -logFile "%~dp0Build\unity-build.log"
if exist "%~dp0Build\Windows\LEFT.exe" (echo Build complete: Build\Windows\LEFT.exe) else (echo Build failed. Read Build\unity-build.log)
pause
