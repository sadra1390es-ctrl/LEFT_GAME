; LEFT Setup template for Inno Setup
; Build the Windows player first from Unity, then open this file in Inno Setup.
#define MyAppName "LEFT Survival"
#define MyAppVersion "0.1.0"
#define MyAppPublisher "LEFT Project"
#define MyAppExeName "LEFT.exe"

[Setup]
AppId={{A03A8D1E-5E28-44B0-9E6A-1EFA00000001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\LEFT Survival
DefaultGroupName={#MyAppName}
OutputDir=Output
OutputBaseFilename=LEFT_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
; Before compiling, verify that the source folder below matches your Unity build output.

[Files]
Source: "..\Build\Windows\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\LEFT Survival"; Filename: "{app}\LEFT.exe"
Name: "{autodesktop}\LEFT Survival"; Filename: "{app}\LEFT.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Run]
Filename: "{app}\LEFT.exe"; Description: "Launch LEFT Survival"; Flags: postinstall nowait skipifsilent
