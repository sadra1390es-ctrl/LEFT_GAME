@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title LEFT - Windows Build and Installer

echo ==================================================
echo  LEFT SURVIVAL - Build Windows EXE and Setup.exe
echo ==================================================
echo.
set "UNITY_EXE="
for %%P in ("C:\Program Files\Unity\Hub\Editor\6000.0.35f1\Editor\Unity.exe" "C:\Program Files\Unity\Hub\Editor\6000.0.XXf1\Editor\Unity.exe" "C:\Program Files\Unity\Editor\Unity.exe") do (
  if exist %%~P set "UNITY_EXE=%%~P"
)
if not defined UNITY_EXE (
  for /d %%D in ("C:\Program Files\Unity\Hub\Editor\*") do if exist "%%~fD\Editor\Unity.exe" set "UNITY_EXE=%%~fD\Editor\Unity.exe"
)
if not defined UNITY_EXE (
  echo ERROR: Unity Editor was not found.
  echo Install Unity 6 using Unity Hub and include Windows Build Support.
  echo Then run this file again.
  pause
  exit /b 2
)
echo Unity found: "%UNITY_EXE%"
echo Building the Windows x64 game. This may take several minutes...
"%UNITY_EXE%" -batchmode -quit -projectPath "%~dp0" -executeMethod LEFTBuild.BuildWindows -logFile "%~dp0Build\unity-build.log"
if errorlevel 1 (
  echo.
  echo Build command returned an error. Check Build\unity-build.log
  pause
  exit /b 3
)
if not exist "%~dp0Build\Windows\LEFT.exe" (
  echo ERROR: LEFT.exe was not created. Check Build\unity-build.log
  pause
  exit /b 4
)
echo.
echo SUCCESS: Game build is at Build\Windows\LEFT.exe
set "ISCC="
for %%P in ("C:\Program Files (x86)\Inno Setup 6\ISCC.exe" "C:\Program Files\Inno Setup 6\ISCC.exe") do if exist %%~P set "ISCC=%%~P"
if not defined ISCC (
  echo Inno Setup was not found, so Setup.exe was not created.
  echo Install Inno Setup 6, then run this file again.
  echo The standalone game build is still in Build\Windows.
  pause
  exit /b 0
)
"%ISCC%" "%~dp0Installer\LEFT_Setup.iss"
if errorlevel 1 (
  echo Installer compilation failed. Check the Inno Setup output above.
  pause
  exit /b 5
)
echo.
echo SUCCESS: Installer created in Installer\Output\LEFT_Setup.exe
pause
