using UnityEngine;
public class LEFTHUD : MonoBehaviour
{
    LEFTPlayerController p; GUIStyle title, body, small;
    void OnGUI(){if(p==null)p=FindObjectOfType<LEFTPlayerController>();if(p==null)return;
      if(title==null){title=new GUIStyle(GUI.skin.label){fontSize=21,fontStyle=FontStyle.Bold};body=new GUIStyle(GUI.skin.label){fontSize=15};small=new GUIStyle(GUI.skin.label){fontSize=12};title.normal.textColor=body.normal.textColor=small.normal.textColor=Color.white;}
      GUI.color=new Color(.025f,.04f,.035f,.86f);GUI.Box(new Rect(14,14,330,236),GUIContent.none);GUI.color=Color.white;
      GUI.Label(new Rect(28,20,290,30),"LEFT  /  SURVIVAL",title);
      DrawMeter(28,55,275,12,p.health/100f,new Color(.78f,.18f,.13f));GUI.Label(new Rect(28,69,280,20),$"HEALTH  {p.health} / 100",body);
      DrawMeter(28,94,275,9,p.hunger/100f,new Color(.78f,.53f,.18f));GUI.Label(new Rect(28,105,130,18),$"HUNGER {Mathf.RoundToInt(p.hunger)}",small);
      DrawMeter(172,94,130,9,p.thirst/100f,new Color(.20f,.53f,.85f));GUI.Label(new Rect(172,105,130,18),$"THIRST {Mathf.RoundToInt(p.thirst)}",small);
      DrawMeter(28,130,275,8,p.stamina/100f,new Color(.35f,.75f,.40f));GUI.Label(new Rect(28,140,280,18),$"STAMINA {Mathf.RoundToInt(p.stamina)}",small);
      GUI.Label(new Rect(28,161,290,22),$"WOOD  {p.wood}     STONE  {p.stone}",body);
      GUI.Label(new Rect(28,187,300,45),"WASD move | Shift sprint | E gather\nLMB attack | B wall | C campfire",small);
      GUI.Label(new Rect(Screen.width/2-10,Screen.height/2-15,30,30),"+",title);
      GUI.Label(new Rect(18,Screen.height-56,900,24),p.status,body);
      GUI.Label(new Rect(18,Screen.height-30,1100,20),"1 Eat ration  |  2 Drink water  |  F5 Save  |  F9 Load  |  Esc Unlock mouse",small);
      if(p.health<=0){GUI.color=new Color(0,0,0,.86f);GUI.Box(new Rect(Screen.width/2-190,Screen.height/2-75,380,150),GUIContent.none);GUI.color=Color.white;GUI.Label(new Rect(Screen.width/2-130,Screen.height/2-49,300,36),"YOU WERE DEFEATED",title);GUI.Label(new Rect(Screen.width/2-130,Screen.height/2+2,300,24),"Press R to restart",body);}}
    void DrawMeter(float x,float y,float w,float h,float v,Color c){GUI.color=new Color(.13f,.15f,.13f,1);GUI.DrawTexture(new Rect(x,y,w,h),Texture2D.whiteTexture);GUI.color=c;GUI.DrawTexture(new Rect(x,y,w*Mathf.Clamp01(v),h),Texture2D.whiteTexture);GUI.color=Color.white;}
}
