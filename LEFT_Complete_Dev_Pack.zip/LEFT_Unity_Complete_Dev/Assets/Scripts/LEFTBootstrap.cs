using UnityEngine;

public class LEFTBootstrap : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void AutoStart()
    {
        if (FindObjectOfType<LEFTBootstrap>() == null)
            new GameObject("LEFT Bootstrap").AddComponent<LEFTBootstrap>();
    }

    public static Material MakeMat(Color c, float metallic = 0f, float smooth = 0.2f)
    {
        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
        var mat = new Material(shader);
        mat.color = c;
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", metallic);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", smooth);
        if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", smooth);
        return mat;
    }

    void Start()
    {
        if (FindObjectOfType<LEFTPlayerController>() != null) return;
        Random.InitState(System.Environment.TickCount);
        SetupLighting();
        new GameObject("LEFT Audio Manager").AddComponent<LEFTAudioManager>();
        new GameObject("LEFT World Clock").AddComponent<LEFTWorldClock>();
        new GameObject("LEFT Build System").AddComponent<LEFTBuildSystem>();
        Material ground = MakeMat(new Color(.18f,.24f,.15f));
        Material bark = MakeMat(new Color(.19f,.105f,.055f));
        Material leafA = MakeMat(new Color(.075f,.19f,.105f));
        Material leafB = MakeMat(new Color(.12f,.25f,.13f));
        Material stone = MakeMat(new Color(.32f,.34f,.33f), .08f, .18f);
        TerrainData td = CreateTerrain(ground);
        var player = CreatePlayer(td);
        for (int i=0;i<260;i++)
        {
            Vector3 p=RandomGround(td);
            if (new Vector2(p.x,p.z).magnitude < 22) continue;
            CreateTree(p, Random.Range(.8f,1.5f), bark, Random.value>.5f?leafA:leafB);
        }
        for (int i=0;i<85;i++)
        {
            Vector3 p=RandomGround(td);
            if (new Vector2(p.x,p.z).magnitude < 9) continue;
            var go=GameObject.CreatePrimitive(PrimitiveType.Sphere);
            go.name="Stone Deposit"; go.transform.position=p+Vector3.up*.35f;
            go.transform.localScale=new Vector3(Random.Range(.55f,1.1f),Random.Range(.4f,.8f),Random.Range(.55f,1.1f));
            go.GetComponent<Renderer>().sharedMaterial=stone;
            var node=go.AddComponent<LEFTResourceNode>(); node.kind=LEFTResourceNode.ResourceKind.Stone;
        }
        for (int i=0;i<55;i++)
        {
            Vector3 p=RandomGround(td);
            if (new Vector2(p.x,p.z).magnitude < 12) continue;
            var go=GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            go.name="Fallen Timber"; go.transform.position=p+Vector3.up*.22f;
            go.transform.rotation=Quaternion.Euler(0,Random.Range(0,180),90);
            go.transform.localScale=new Vector3(.25f,Random.Range(1.1f,1.8f),.25f);
            go.GetComponent<Renderer>().sharedMaterial=bark;
            var node=go.AddComponent<LEFTResourceNode>(); node.kind=LEFTResourceNode.ResourceKind.Wood;
        }
        for (int i=0;i<12;i++)
        {
            Vector3 p=RandomGround(td);
            if (new Vector2(p.x,p.z).magnitude < 35) p += new Vector3(48,0,34);
            var enemy=GameObject.CreatePrimitive(PrimitiveType.Capsule);
            enemy.name="Hostile Scavenger"; enemy.transform.position=p+Vector3.up;
            enemy.GetComponent<Renderer>().sharedMaterial=MakeMat(new Color(.22f,.13f,.09f));
            var ai=enemy.AddComponent<LEFTEnemyAI>(); ai.player=player.transform;
        }
        new GameObject("LEFT HUD").AddComponent<LEFTHUD>();
        Cursor.lockState=CursorLockMode.Locked; Cursor.visible=false;
    }

    void SetupLighting()
    {
        RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Trilight;
        RenderSettings.ambientSkyColor=new Color(.38f,.45f,.54f);
        RenderSettings.ambientEquatorColor=new Color(.24f,.28f,.24f);
        RenderSettings.ambientGroundColor=new Color(.12f,.13f,.10f);
        RenderSettings.fog=true; RenderSettings.fogMode=FogMode.ExponentialSquared;
        RenderSettings.fogColor=new Color(.48f,.55f,.53f); RenderSettings.fogDensity=.0017f;
        var sunGO=new GameObject("LEFT Sun"); var sun=sunGO.AddComponent<Light>();
        sun.type=LightType.Directional; sun.intensity=1.25f;
        sun.color=new Color(1f,.91f,.78f); sun.shadows=LightShadows.Soft;
        sunGO.transform.rotation=Quaternion.Euler(38,-28,0);
    }

    TerrainData CreateTerrain(Material mat)
    {
        const int res=257;
        var td=new TerrainData(); td.heightmapResolution=res; td.size=new Vector3(320,34,320);
        float[,] h=new float[res,res];
        for(int z=0;z<res;z++) for(int x=0;x<res;x++)
        {
            float nx=x/(float)(res-1), nz=z/(float)(res-1);
            float broad=Mathf.PerlinNoise(nx*3.2f+3,nz*3.2f+8)*.52f;
            float detail=Mathf.PerlinNoise(nx*12f+20,nz*12f+2)*.10f;
            float ridge=Mathf.PerlinNoise(nx*6f+8,nz*6f+19)*.12f;
            float center=1f-Mathf.Clamp01(Vector2.Distance(new Vector2(nx,nz),new Vector2(.5f,.5f))/.20f);
            h[z,x]=Mathf.Lerp(broad+detail+ridge,.07f,center)*.30f;
        }
        td.SetHeights(0,0,h);
        var terrainGO=Terrain.CreateTerrainGameObject(td);
        terrainGO.name="LEFT Wilderness Terrain";
        terrainGO.transform.position=new Vector3(-160,0,-160);
        terrainGO.GetComponent<Terrain>().materialTemplate=mat;
        terrainGO.GetComponent<Terrain>().drawInstanced=true;
        return td;
    }

    GameObject CreatePlayer(TerrainData td)
    {
        var player=new GameObject("LEFT Player");
        player.transform.position=new Vector3(0,GroundHeight(td,0,0)+2,0);
        var cc=player.AddComponent<CharacterController>(); cc.height=1.8f; cc.radius=.34f; cc.center=new Vector3(0,.9f,0);
        var pc=player.AddComponent<LEFTPlayerController>();
        var camGO=new GameObject("First Person Camera"); camGO.transform.SetParent(player.transform);
        camGO.transform.localPosition=new Vector3(0,1.58f,0);
        var cam=camGO.AddComponent<Camera>(); cam.fieldOfView=78; cam.nearClipPlane=.05f;
        camGO.AddComponent<AudioListener>(); pc.cameraTransform=camGO.transform;
        return player;
    }
    float GroundHeight(TerrainData td,float x,float z)
    {
        int ix=Mathf.Clamp(Mathf.RoundToInt((x+160)/320*256),0,256);
        int iz=Mathf.Clamp(Mathf.RoundToInt((z+160)/320*256),0,256);
        return td.GetHeight(ix,iz);
    }
    Vector3 RandomGround(TerrainData td)
    {
        float x=Random.Range(-148,148), z=Random.Range(-148,148);
        return new Vector3(x,GroundHeight(td,x,z),z);
    }
    void CreateTree(Vector3 p,float s,Material bark,Material leaves)
    {
        var root=new GameObject("Pine Tree"); root.transform.position=p;
        var trunk=GameObject.CreatePrimitive(PrimitiveType.Cylinder); trunk.transform.SetParent(root.transform);
        trunk.transform.localPosition=new Vector3(0,1.65f*s,0); trunk.transform.localScale=new Vector3(.24f*s,1.65f*s,.24f*s);
        trunk.GetComponent<Renderer>().sharedMaterial=bark; Destroy(trunk.GetComponent<Collider>());
        for(int j=0;j<3;j++)
        {
            var crown=GameObject.CreatePrimitive(PrimitiveType.Sphere); crown.transform.SetParent(root.transform);
            crown.transform.localPosition=new Vector3(0,(2f+j*.66f)*s,0);
            crown.transform.localScale=new Vector3((1.9f-j*.38f)*s,(1.65f-j*.17f)*s,(1.9f-j*.38f)*s);
            crown.GetComponent<Renderer>().sharedMaterial=leaves; Destroy(crown.GetComponent<Collider>());
        }
    }
}