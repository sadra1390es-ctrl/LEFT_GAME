using UnityEngine;

public class LEFTBuildSystem : MonoBehaviour
{
    public static LEFTBuildSystem Instance;
    Material woodMat, stoneMat;
    void Awake() { Instance = this; woodMat = LEFTBootstrap.MakeMat(new Color(.30f,.17f,.08f)); stoneMat = LEFTBootstrap.MakeMat(new Color(.28f,.30f,.29f)); }
    public bool TryBuild(LEFTPlayerController p)
    {
        if (!p) return false;
        if (p.wood < 12 || p.stone < 4) { p.status = "Need 12 wood + 4 stone to build a shelter wall."; return false; }
        Vector3 pos = p.transform.position + p.transform.forward * 3f; pos.y += 1.1f;
        var wall = GameObject.CreatePrimitive(PrimitiveType.Cube); wall.name = "Player Built Shelter Wall";
        wall.transform.position = pos; wall.transform.rotation = Quaternion.Euler(0, p.transform.eulerAngles.y, 0);
        wall.transform.localScale = new Vector3(3.4f, 2.2f, .22f);
        wall.GetComponent<Renderer>().sharedMaterial = woodMat;
        p.wood -= 12; p.stone -= 4; p.status = "Shelter wall built. Keep gathering to expand your base."; LEFTAudioManager.Play("build");
        return true;
    }
    public void TryBuildCampfire(LEFTPlayerController p)
    {
        if (!p) return;
        if (p.wood < 8 || p.stone < 6) { p.status = "Campfire costs 8 wood + 6 stone."; return; }
        Vector3 pos = p.transform.position + p.transform.forward * 2f; pos.y -= .7f;
        var fire = new GameObject("Built Campfire"); fire.transform.position = pos;
        var stones = GameObject.CreatePrimitive(PrimitiveType.Cylinder); stones.transform.SetParent(fire.transform); stones.transform.localPosition = Vector3.zero; stones.transform.localScale = new Vector3(1.15f,.16f,1.15f); stones.GetComponent<Renderer>().sharedMaterial = stoneMat;
        var flame = GameObject.CreatePrimitive(PrimitiveType.Sphere); flame.name="Fire Glow"; flame.transform.SetParent(fire.transform); flame.transform.localPosition = new Vector3(0,.45f,0); flame.transform.localScale = new Vector3(.38f,.65f,.38f); flame.GetComponent<Renderer>().sharedMaterial = LEFTBootstrap.MakeMat(new Color(1f,.26f,.04f),0,.65f); Object.Destroy(flame.GetComponent<Collider>());
        var light = fire.AddComponent<Light>(); light.type=LightType.Point; light.range=9; light.intensity=2.2f; light.color=new Color(1f,.35f,.10f);
        p.wood -= 8; p.stone -= 6; p.status = "Campfire placed. It lights the area at night."; LEFTAudioManager.Play("build"); LEFTAudioManager.PlayAt("fire", pos);
    }
}
