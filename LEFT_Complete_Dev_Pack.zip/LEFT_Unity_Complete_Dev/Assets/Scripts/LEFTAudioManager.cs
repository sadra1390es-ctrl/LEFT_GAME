using UnityEngine;

// Procedural audio means the prototype has sound even before external audio assets are imported.
public class LEFTAudioManager : MonoBehaviour
{
    public static LEFTAudioManager Instance;
    AudioSource effects, ambience;
    AudioClip collectClip, hitClip, hurtClip, buildClip, stepClip, enemyClip, fireClip, windClip;
    float ambienceTimer;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        effects = gameObject.AddComponent<AudioSource>(); effects.playOnAwake = false; effects.spatialBlend = 0.25f;
        ambience = gameObject.AddComponent<AudioSource>(); ambience.playOnAwake = false; ambience.loop = true; ambience.volume = 0.12f; ambience.spatialBlend = 0f;
        collectClip = Tone("LEFT_Collect", 880f, .11f, .16f, 0);
        hitClip = Tone("LEFT_Hit", 105f, .18f, .55f, 1);
        hurtClip = Tone("LEFT_Hurt", 170f, .28f, .45f, 1);
        buildClip = Tone("LEFT_Build", 240f, .24f, .40f, 2);
        stepClip = Tone("LEFT_Footstep", 75f, .075f, .45f, 2);
        enemyClip = Tone("LEFT_Enemy", 95f, .30f, .34f, 3);
        fireClip = Noise("LEFT_Campfire", 3f, .11f);
        windClip = Noise("LEFT_Wind", 5f, .07f);
        ambience.clip = windClip; ambience.Play();
    }

    AudioClip Tone(string name, float frequency, float duration, float volume, int noiseMix)
    {
        int rate = 22050, count = Mathf.CeilToInt(rate * duration);
        float[] data = new float[count];
        for (int i=0;i<count;i++)
        {
            float t=i/(float)rate, env=Mathf.Pow(1f-i/(float)count, 2.2f);
            float s=Mathf.Sin(2f*Mathf.PI*frequency*t);
            if(noiseMix>0) s=Mathf.Lerp(s,Random.Range(-1f,1f),noiseMix==1?.65f:noiseMix==2?.8f:.9f);
            data[i]=s*env*volume;
        }
        var clip=AudioClip.Create(name,count,1,rate,false); clip.SetData(data,0); return clip;
    }
    AudioClip Noise(string name, float seconds, float volume)
    {
        int rate=22050,count=Mathf.CeilToInt(rate*seconds); float[] data=new float[count];
        float smooth=0;
        for(int i=0;i<count;i++) { smooth=Mathf.Lerp(smooth,Random.Range(-1f,1f),.08f); data[i]=smooth*volume; }
        var clip=AudioClip.Create(name,count,1,rate,false); clip.SetData(data,0); clip.SetLoop(true); return clip;
    }
    public static void Play(string cue)
    {
        if(!Instance)return;
        AudioClip clip=cue=="collect"?Instance.collectClip:cue=="hit"?Instance.hitClip:cue=="hurt"?Instance.hurtClip:cue=="build"?Instance.buildClip:cue=="step"?Instance.stepClip:Instance.enemyClip;
        Instance.effects.pitch=cue=="step"?Random.Range(.85f,1.12f):Random.Range(.94f,1.06f);
        Instance.effects.PlayOneShot(clip, cue=="step"?.45f:1f);
    }
    public static void PlayAt(string cue, Vector3 position)
    {
        if(!Instance)return;
        var go=new GameObject("LEFT 3D Sound - "+cue); go.transform.position=position;
        var src=go.AddComponent<AudioSource>(); src.spatialBlend=1f; src.minDistance=2f; src.maxDistance=20f;
        src.clip=cue=="fire"?Instance.fireClip:Instance.enemyClip; src.volume=cue=="fire"?.7f:.7f; src.loop=cue=="fire"; src.Play();
        if(!src.loop)Destroy(go,src.clip.length+0.1f);
    }
    public static void SetVolume(float value) { if(Instance){Instance.effects.volume=value; Instance.ambience.volume=value*.25f;} }
}
