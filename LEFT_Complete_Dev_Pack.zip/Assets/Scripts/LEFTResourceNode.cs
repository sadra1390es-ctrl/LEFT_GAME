using UnityEngine;
public class LEFTResourceNode : MonoBehaviour
{
    public enum ResourceKind{Wood,Stone}
    public ResourceKind kind=ResourceKind.Wood;
    bool collected;
    public int Collect()
    {
        if(collected)return 0;
        collected=true;
        int amount=kind==ResourceKind.Wood?Random.Range(3,8):Random.Range(2,6);
        Destroy(gameObject);
        return amount;
    }
}