using UnityEngine;

public class LEFTWorldClock : MonoBehaviour
{
    public float dayLengthSeconds = 480f;
    public float timeOfDay = 0.28f;
    Light sun;
    void Start()
    {
        var go = GameObject.Find("LEFT Sun");
        if (go) sun = go.GetComponent<Light>();
    }
    void Update()
    {
        timeOfDay = (timeOfDay + Time.deltaTime / Mathf.Max(60f, dayLengthSeconds)) % 1f;
        float angle = timeOfDay * 360f - 90f;
        if (sun)
        {
            sun.transform.rotation = Quaternion.Euler(angle, -28f, 0f);
            float daylight = Mathf.Clamp01(Mathf.Sin(timeOfDay * Mathf.PI * 2f) * 1.4f + .15f);
            sun.intensity = Mathf.Lerp(.12f, 1.25f, daylight);
            sun.color = Color.Lerp(new Color(.22f,.29f,.48f), new Color(1f,.88f,.72f), daylight);
        }
        RenderSettings.ambientIntensity = Mathf.Lerp(.35f, 1f, Mathf.Clamp01(Mathf.Sin(timeOfDay * Mathf.PI * 2f) + .25f));
    }
    public string ClockLabel => timeOfDay < .5f ? "DAY" : "NIGHT";
}
