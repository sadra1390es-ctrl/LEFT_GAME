using UnityEngine;

public class LEFTEnemyAI : MonoBehaviour
{
    public Transform player;
    public float detectRange=26f, loseRange=38f, speed=2.15f, attackRange=1.75f;
    int hp=100; float attackCooldown, wanderTimer; Vector3 wanderTarget; bool chasing;
    void Start(){wanderTarget=transform.position;}
    void Update()
    {
        if(!player)return;
        var pc=player.GetComponent<LEFTPlayerController>(); if(pc==null)return;
        if(pc.health<=0)return;
        float d=Vector3.Distance(transform.position,player.position);
        if(!chasing&&d<detectRange)chasing=true;
        if(chasing&&d>loseRange)chasing=false;
        Vector3 target=transform.position;
        if(chasing)target=player.position;
        else
        {
            wanderTimer-=Time.deltaTime;
            if(wanderTimer<=0){wanderTimer=Random.Range(2f,5f);wanderTarget=transform.position+new Vector3(Random.Range(-5,5),0,Random.Range(-5,5));}
            target=wanderTarget;
        }
        Vector3 flat=target-transform.position; flat.y=0;
        if(flat.sqrMagnitude>.2f)
        {
            transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(flat),Time.deltaTime*3.5f);
            transform.position+=transform.forward*(chasing?speed: speed*.35f)*Time.deltaTime;
        }
        if(chasing&&d<attackRange&&Time.time>attackCooldown)
        {
            attackCooldown=Time.time+1.35f; pc.Hurt(9);
        }
    }
    public void TakeDamage(int amount){hp-=amount;if(hp<=0)Destroy(gameObject);}
}