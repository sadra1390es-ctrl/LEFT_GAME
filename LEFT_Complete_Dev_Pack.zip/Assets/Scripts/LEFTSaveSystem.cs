using UnityEngine;

public class LEFTSaveSystem : MonoBehaviour
{
    public static void Save(LEFTPlayerController p)
    {
        if (!p) return;
        PlayerPrefs.SetFloat("LEFT_x",p.transform.position.x); PlayerPrefs.SetFloat("LEFT_y",p.transform.position.y); PlayerPrefs.SetFloat("LEFT_z",p.transform.position.z);
        PlayerPrefs.SetInt("LEFT_health",p.health); PlayerPrefs.SetInt("LEFT_wood",p.wood); PlayerPrefs.SetInt("LEFT_stone",p.stone);
        PlayerPrefs.SetFloat("LEFT_hunger",p.hunger); PlayerPrefs.SetFloat("LEFT_thirst",p.thirst); PlayerPrefs.Save();
        p.status="Game saved.";
    }
    public static void Load(LEFTPlayerController p)
    {
        if (!p || !PlayerPrefs.HasKey("LEFT_x")) { if(p)p.status="No save found yet. Press F5 to save."; return; }
        p.controller.enabled=false;
        p.transform.position=new Vector3(PlayerPrefs.GetFloat("LEFT_x"),PlayerPrefs.GetFloat("LEFT_y"),PlayerPrefs.GetFloat("LEFT_z"));
        p.controller.enabled=true;
        p.health=PlayerPrefs.GetInt("LEFT_health",100); p.wood=PlayerPrefs.GetInt("LEFT_wood",0); p.stone=PlayerPrefs.GetInt("LEFT_stone",0);
        p.hunger=PlayerPrefs.GetFloat("LEFT_hunger",100); p.thirst=PlayerPrefs.GetFloat("LEFT_thirst",100);
        p.status="Saved survivor state loaded.";
    }
}
