using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(CharacterController))]
public class LEFTPlayerController : MonoBehaviour
{
    public Transform cameraTransform;
    public CharacterController controller;
    public float walkSpeed=4.8f, sprintSpeed=7.1f, jumpHeight=1.05f, sensitivity=2.0f;
    public int health=100, wood, stone;
    public float hunger=100f, thirst=100f, stamina=100f;
    public string status="Explore, gather resources and survive.";
    float verticalVelocity, pitch, hungerTick, thirstTick, attackCooldown, staminaTick;
    bool dead;
    void Start(){controller=GetComponent<CharacterController>();}
    void Update()
    {
        if(dead){if(Input.GetKeyDown(KeyCode.R))SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);return;}
        if(Input.GetKeyDown(KeyCode.F5))LEFTSaveSystem.Save(this);
        if(Input.GetKeyDown(KeyCode.F9))LEFTSaveSystem.Load(this);
        if(Input.GetKeyDown(KeyCode.B)&&LEFTBuildSystem.Instance)LEFTBuildSystem.Instance.TryBuild(this);
        if(Input.GetKeyDown(KeyCode.C)&&LEFTBuildSystem.Instance)LEFTBuildSystem.Instance.TryBuildCampfire(this);
        if(Input.GetKeyDown(KeyCode.Alpha1)){hunger=Mathf.Min(100,hunger+25);status="Ate a ration (+25 hunger).";}
        if(Input.GetKeyDown(KeyCode.Alpha2)){thirst=Mathf.Min(100,thirst+30);status="Drank clean water (+30 thirst).";}
        if(Cursor.lockState!=CursorLockMode.Locked){if(Input.GetMouseButtonDown(0)){Cursor.lockState=CursorLockMode.Locked;Cursor.visible=false;}return;}
        transform.Rotate(0,Input.GetAxis("Mouse X")*sensitivity,0);
        pitch=Mathf.Clamp(pitch-Input.GetAxis("Mouse Y")*sensitivity,-82,82); cameraTransform.localRotation=Quaternion.Euler(pitch,0,0);
        Vector3 input=new Vector3(Input.GetAxisRaw("Horizontal"),0,Input.GetAxisRaw("Vertical")); if(input.sqrMagnitude>1)input.Normalize();
        bool sprint=Input.GetKey(KeyCode.LeftShift)&&input.sqrMagnitude>.1f&&stamina>1;
        float speed=sprint?sprintSpeed:walkSpeed;
        if(sprint)stamina=Mathf.Max(0,stamina-22*Time.deltaTime);else stamina=Mathf.Min(100,stamina+13*Time.deltaTime);
        if(controller.isGrounded&&verticalVelocity<0)verticalVelocity=-2f;
        if(controller.isGrounded&&Input.GetButtonDown("Jump"))verticalVelocity=Mathf.Sqrt(jumpHeight*-2f*Physics.gravity.y);
        verticalVelocity+=Physics.gravity.y*Time.deltaTime;
        controller.Move((transform.TransformDirection(input)*speed+Vector3.up*verticalVelocity)*Time.deltaTime);
        if(Input.GetKeyDown(KeyCode.E))Interact();
        if(Input.GetMouseButtonDown(0)&&Time.time>=attackCooldown)Attack();
        SurvivalTick(); if(Input.GetKeyDown(KeyCode.Escape)){Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
    }
    void SurvivalTick(){hungerTick+=Time.deltaTime;thirstTick+=Time.deltaTime;if(hungerTick>=12){hungerTick=0;hunger=Mathf.Max(0,hunger-1);}if(thirstTick>=8){thirstTick=0;thirst=Mathf.Max(0,thirst-1);}if((hunger<=0||thirst<=0)&&Time.frameCount%90==0)Hurt(1);}
    void Interact(){if(Physics.Raycast(cameraTransform.position,cameraTransform.forward,out RaycastHit hit,3.5f)){var node=hit.collider.GetComponentInParent<LEFTResourceNode>();if(node){int amount=node.Collect();if(node.kind==LEFTResourceNode.ResourceKind.Wood)wood+=amount;else stone+=amount;status=amount>0?$"Collected {amount} {node.kind}.":"Already collected.";return;}status="Nothing to collect here.";}}
    void Attack(){attackCooldown=Time.time+.48f;if(Physics.Raycast(cameraTransform.position,cameraTransform.forward,out RaycastHit hit,3.1f)){var enemy=hit.collider.GetComponentInParent<LEFTEnemyAI>();if(enemy){enemy.TakeDamage(35);status="Hit scavenger (-35 HP).";}}}
    public void Hurt(int amount){if(dead)return;health=Mathf.Max(0,health-amount);if(health==0){dead=true;status="You were defeated. Press R to restart.";Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}}
    public void Restore(int amount){health=Mathf.Min(100,health+amount);}
}
